# Rails Project Template

A minimal starter for Ruby on Rails apps.
