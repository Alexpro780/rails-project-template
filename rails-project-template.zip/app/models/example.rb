class Example < ApplicationRecord
end
